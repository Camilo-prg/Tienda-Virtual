/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package demoshop2;

/**
 *
 * @author ASUS
 */
public class Producto {
    private String mNombre;
    private String mDescripcion;
    private Double mCosto;
    private Double mPrecio;
   
    

    /**
     * @return the mNombre
     */
    public String getNombre() {
        return mNombre;
    }

    /**
     * @param mNombre the mNombre to set
     */
    public void setNombre(String mNombre) {
        this.mNombre = mNombre;
    }

    /**
     * @return the mDescripcion
     */
    public String getDescripcion() {
        return mDescripcion;
    }

    /**
     * @param mDescripcion the mDescripcion to set
     */
    public void setDescripcion(String mDescripcion) {
        this.mDescripcion = mDescripcion;
    }

    /**
     * @return the mCosto
     */
    public Double getCosto() {
        return mCosto;
    }

    /**
     * @param mCosto the mCosto to set
     */
    public void setCosto(Double mCosto) {
        this.mCosto = mCosto;
    }

    /**
     * @return the mPrecio
     */
    public Double getPrecio() {
        return mPrecio;
    }

    /**
     * @param mPrecio the mPrecio to set
     */
    public void setPrecio(Double mPrecio) {
        this.mPrecio = mPrecio;
    }

}
