/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package demoshop2;

import Vistas.Vista;
import java.util.ArrayList;

/**
 *
 * @author ASUS
 */
public class Demoshop2 {
    
    public static String mUsuario;
    public static String mPass;

    public static boolean mEsComprador;
    public static boolean mEsAdmin;

    public static ArrayList<Usuario> mListaDeUsuarios = new ArrayList();
    public static ArrayList<Producto> mListaDeProductos = new ArrayList();
    public static ArrayList<Producto> mListaDeDeseados = new ArrayList();
            
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here}


        Usuario usuario1 = new Usuario();
        usuario1.setNombre("Douglas");
        usuario1.setPass("douglas22");
        usuario1.setCorreoElectronico("douglasnegretepacheco22@gmail.com");
        usuario1.setmRol("Creador");

        Usuario usuario2 = new Usuario();
        usuario2.setNombre("Admin");
        usuario2.setPass("1234");
        usuario2.setmRol("Administrador");
        
        Usuario usuario3 = new Usuario();
        usuario3.setNombre("Comprador");
        usuario3.setPass("12345");
        usuario3.setmRol("Comprador");
       

        //estos estan por defecto
        mListaDeUsuarios.add(usuario1); //Tiene el rol de administrador y Comprador
        mListaDeUsuarios.add(usuario2); //Tiene el rol de administrador
        mListaDeUsuarios.add(usuario3); //Tiene el rol de Comprador

        Vista login = new Vista();
        login.setVisible(true);

    }
    
}
